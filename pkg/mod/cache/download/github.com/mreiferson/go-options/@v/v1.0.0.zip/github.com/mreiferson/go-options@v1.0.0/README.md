# go-options

Resolve configuration values set via command line flags, config files, and default struct values.

[![Build Status](https://secure.travis-ci.org/mreiferson/go-options.png?branch=master)](http://travis-ci.org/mreiferson/go-options) [![GoDoc](https://godoc.org/github.com/mreiferson/go-options?status.svg)](https://godoc.org/github.com/mreiferson/go-options) [![GitHub release](https://img.shields.io/github/release/mreiferson/go-options.svg)](https://github.com/mreiferson/go-options/releases/latest)
